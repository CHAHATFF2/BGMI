#include "logobyypass.h"
int hsub307(){
printf("Injector based patching..");
}


int main(){


XeroHex(Ue4 +0x8E2926C",("63 00 00 00");
XeroHex(Ue4 +0x6393D70",("63 00 00 00");
XeroHex(Ue4 +0x8FC9120",("63 00 00 00");
XeroHex(Ue4 +0x8FB668C",("63 00 00 00");
XeroHex(Ue4 +0x63AA7F0",("63 00 00 00");
XeroHex(Ue4 +0x6393D70",("63 00 00 00");
XeroHex(Ue4 +0x8E2926C",("63 00 00 00");
XeroHex(Ue4 +0x20C964",("63 00 00 00");
XeroHex(Ue4 +0xe1d94",("63 00 00 00");
XeroHex(Ue4 +0xe1d98",("63 00 00 00");
XeroHex(Ue4 +0xe1d9c",("63 00 00 00");
XeroHex(Ue4 +0xe1da0",("63 00 00 00");
XeroHex(Ue4 +0xe1da4",("63 00 00 00");
XeroHex(Ue4 +0xe1da8",("63 00 00 00");
XeroHex(Ue4 +0xe1dac",("63 00 00 00");
XeroHex(Ue4 +0xe1db0",("63 00 00 00");
XeroHex(Ue4 +0xe1db4",("63 00 00 00");
XeroHex(Ue4 +0xe1db8",("63 00 00 00");
XeroHex(Ue4 +0xe1dbc",("63 00 00 00");
XeroHex(Ue4 +0xe1dc0",("63 00 00 00");
XeroHex(Ue4 +0xe1dc4",("63 00 00 00");
XeroHex(Ue4 +0xe1dc8",("63 00 00 00");
XeroHex(Ue4 +0xe1dcc",("63 00 00 00");
XeroHex(Ue4 +0xe1dd0",("63 00 00 00");
XeroHex(Ue4 +0xe1dd4",("63 00 00 00");    
XeroHex(Ue4 +0x1120",("63 00 00 00");
XeroHex(Ue4 +0x1124",("63 00 00 00");
XeroHex(Ue4 +0x1128",("63 00 00 00");
XeroHex(Ue4 +0x112C",("63 00 00 00");
XeroHex(Ue4 +0x1130",("63 00 00 00");
XeroHex(Ue4 +0x1134",("63 00 00 00");
XeroHex(Ue4 +0x1138",("63 00 00 00");
XeroHex(Ue4 +0x113C",("63 00 00 00");
XeroHex(Ue4 +0x1140",("63 00 00 00");
XeroHex(Ue4 +0x1144",("63 00 00 00");
XeroHex(Ue4 +0x1148",("63 00 00 00");
XeroHex(Ue4 +0x114C",("63 00 00 00");
XeroHex(Ue4 +0x1150",("63 00 00 00");
XeroHex(Ue4 +0x1154",("63 00 00 00");
XeroHex(Ue4 +0x1158",("63 00 00 00");
XeroHex(Ue4 +0x115C",("63 00 00 00");
XeroHex(Ue4 +0x1160",("63 00 00 00");
XeroHex(Ue4 +0x1164",("63 00 00 00");
XeroHex(Ue4 +0x1168",("63 00 00 00");
XeroHex(Ue4 +0x116C",("63 00 00 00");
XeroHex(Ue4 +0x1170",("63 00 00 00");
XeroHex(Ue4 +0x1174",("63 00 00 00");
XeroHex(Ue4 +0x1178",("63 00 00 00");
XeroHex(Ue4 +0x117C",("63 00 00 00");
XeroHex(Ue4 +0x1200",("63 00 00 00");
XeroHex(Ue4 +0x18F4",("63 00 00 00");
XeroHex(Ue4 +0x18F8",("63 00 00 00");
XeroHex(Ue4 +0x18FC",("63 00 00 00");
XeroHex(Ue4 +0x1774",("63 00 00 00");
XeroHex(Ue4 +0x1778",("63 00 00 00");
XeroHex(Ue4 +0x177C",("63 00 00 00");
XeroHex(Ue4 +0x1780",("63 00 00 00");
XeroHex(Ue4 +0x1784",("63 00 00 00");
XeroHex(Ue4 +0x1788",("63 00 00 00");
XeroHex(Ue4 +0x178C",("63 00 00 00");
XeroHex(Ue4 +0x1790",("63 00 00 00");
XeroHex(Ue4 +0x1794",("63 00 00 00");
XeroHex(Ue4 +0x1798",("63 00 00 00");
XeroHex(Ue4 +0x179C",("63 00 00 00");
XeroHex(Ue4 +0x17A0",("63 00 00 00");
XeroHex(Ue4 +0x17A4",("63 00 00 00");
XeroHex(Ue4 +0x17A8",("63 00 00 00");
XeroHex(Ue4 +0x17AC",("63 00 00 00");
XeroHex(Ue4 +0x17B0",("63 00 00 00");
XeroHex(Ue4 +0x17B4",("63 00 00 00");
XeroHex(Ue4 +0x17B8",("63 00 00 00");
XeroHex(Ue4 +0x17BC",("63 00 00 00");



//MAHAKAL_BHAGKT  64 BIT BYPASS  
//2.9 UPDATE  (Ue4+ ) BYPASS 

//ADD FULL SAFE BYPASS CPP CPP ONLINE  BYPASS 



